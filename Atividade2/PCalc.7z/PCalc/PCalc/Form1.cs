﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PCalc
{
    public partial class Form1 : Form
    {
        double numero1, numero2;
        public Form1()
        {
            InitializeComponent();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void btnSoma_Click(object sender, EventArgs e)
        {
            txtResultado.Text = Convert.ToString(numero1 + numero2);
        }

        private void btnSub_Click(object sender, EventArgs e)
        {
            txtResultado.Text =Convert.ToString (numero1 - numero2);
        }

        private void btnMult_Click(object sender, EventArgs e)
        {
            txtResultado.Text = Convert.ToString(numero1 * numero2);
        }

        private void btnDiv_Click(object sender, EventArgs e)
        {
            if (numero2 == 0) {
                MessageBox.Show("O número 2 deve ser diferente de 0 para realizar a operação de divisão \"/\"", "Erro ao dividir por 0",
                MessageBoxButtons.OK, MessageBoxIcon.Exclamation);

            } else txtResultado.Text= Convert.ToString(numero1 / numero2);
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtNumero1.Clear();
            txtNumero2.Clear();
            txtResultado.Clear();

        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void txtNumero2_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtNumero2.Text, out numero2))
            {
                MessageBox.Show("número 2 inválido");
                txtNumero2.Focus();

            }
        }

      
        private void txtNumero1_Validated(object sender, EventArgs e)
        {
            if(!Double.TryParse(txtNumero1.Text, out numero1))
            {
                MessageBox.Show("número 1 inválido");
                txtNumero1.Focus();

            }
        }
    }
}
