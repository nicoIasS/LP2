﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade7
{
    public partial class frmExercicio1 : Form
    {
        public frmExercicio1()
        {
            InitializeComponent();
        }

        private void btnWhiteSpace_Click(object sender, EventArgs e)
        {
            string aux = rTxtFrase.Text.ToLower();
            for (int i = 0; i < rTxtFrase.Text.Length; i++) {
               if(aux.IndexOf(aux, ' ') == i)
               {
                    aux = aux.Substring(0, i);
               }
            }
        }
    }
}
