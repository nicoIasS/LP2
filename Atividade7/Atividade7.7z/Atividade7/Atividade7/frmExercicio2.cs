﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade7
{
    public partial class frmExercicio2 : Form
    {
        public frmExercicio2()
        {
            InitializeComponent();
        }

        private void btnCalcH_Click(object sender, EventArgs e)
        {
            int n;
            float h = 0;
            if (int.TryParse(txtN.Text, out n) && n>0) {
                for (int i = 1; i <= n; i++) {
                    h = h + 1f/i;
                }
                txtH.Text = h.ToString();
            }else
            {
                MessageBox.Show("Número Inválido");
            }
        }
    }
}
