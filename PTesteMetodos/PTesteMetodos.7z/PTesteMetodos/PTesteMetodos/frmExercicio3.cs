﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTesteMetodos
{
    public partial class frmExercicio3 : Form
    {
        public frmExercicio3()
        {
            InitializeComponent();
        }

        private void btnRemove_Click(object sender, EventArgs e)
        {
            txtBoxPalavra2.Text = txtBoxPalavra2.Text.Replace(txtBoxPalavra1.Text,"");
        }

        private void btnInverte_Click(object sender, EventArgs e)
        {
            char[] vetor = txtBoxPalavra1.Text.ToCharArray();
            Array.Reverse(vetor);
            txtBoxPalavra2.Text = vetor.ToString();
            foreach (char c in vetor)
            {
                txtBoxPalavra2.Text += c;
            }
            //outro jeito:
            //string auxiliar = new string(vetor);
            //txtBoxPalavra1.Text = auxiliar;
        }
    }
}
