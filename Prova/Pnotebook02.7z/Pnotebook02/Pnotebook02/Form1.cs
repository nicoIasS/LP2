﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace Pnotebook02
{
    public partial class Form1 : Form
    {
        double[,] valorNote = new double[2, 3];
        String aux = "";
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string straux;
            double mediaValNote, mediaGeralNote=0;
            for(int i = 0; i < 2; i++)
            {
                straux = "";
                straux = "\n Notebook: " + (i + 1) + straux + " ";
                mediaValNote = 0;
                for (int j = 0; j < 3; j++) 
                {
                    aux = Interaction.InputBox("Digite o Valor do Notebook " + (i+1) + " na loja " + (j+1));
                    if(!double.TryParse(aux, out valorNote[i, j]) || valorNote[i,j] < 0)
                    {
                        MessageBox.Show("Digite um número maior ou igual a 0");
                        j -= 1;
                    }else
                    {
                        straux+=("    Loja " + (j+1) + " R$ " + String.Format("{0:C2}", valorNote[i,j]));
                        mediaValNote += valorNote[i, j];
                        mediaGeralNote += valorNote[i,j];

                    }

                }
                mediaValNote = mediaValNote / 3.0;
                lBoxSaida.Items.Add(straux + "   Média: R$ " + String.Format( "{0:C2}",mediaValNote));
            }
            mediaGeralNote = mediaGeralNote / 6;
                lBoxSaida.Items.Add("---------------------------------------------------------------------");
                lBoxSaida.Items.Add("Média Geral Computadores : R$ " + String.Format("{0:C2}",mediaGeralNote));

        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            lBoxSaida.Items.Clear();
        }
    }
}
